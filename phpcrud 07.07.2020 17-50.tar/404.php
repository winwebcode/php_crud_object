<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="style.css">
        <link rel="shortcut icon" href="img/favicon/favicon.png" type="image/x-icon">
        <title>Upload avatar</title>
    </head>
    <body>
        <div class="page404">
            <a href="index.php"><img src="img/404.png"></a>
                
        </div>
    </body>
</html>

Для работы необходимо импортировать .sql файл в базу данных MySQL.
default log/pass
login administrator
password qwerty

v.1
Parser of currency with the Central Bank;
Authorization / Registration / Change password / Determine IP;
List of members;
Client database management (add, delete, edit and search clients);

v.1.0.1

Added password hashing: password_hash ("$password", PASSWORD_DEFAULT);

Confirmation of a valid password is added when trying to change a password;

Fix minor bugs;

v.1.0.2

Added log of autharization;

Fix minor bugs;

v.1.0.3

Bringing to MVC Architecture;

Fix Search bug;

v 1.0.4

Add User rights;

Add ban / unban users for Administrators;

v.1.0.5

Add userpic upload;

v.1.0.6

Add default userpics;

v 1.0.7

Add favicon uploader;

Settings page for administrators;

Add 404 page;
<html>
<head>
	<meta charset="UTF-8" />
	<title>Sign Out</title>
	<link rel="stylesheet" type="text/css" href="style.css">
        <link rel="shortcut icon" href="img/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    
<?php
require_once "config.php";
require_once "User.class.php";
?>

<a href='index.php'><img alt="" src="img/bye.png"><br>You Sign Out.</a>

<?php
require_once "footer.php";
?>